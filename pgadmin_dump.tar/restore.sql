--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.itempedido DROP CONSTRAINT fke8138058a7a6bc11;
ALTER TABLE ONLY public.itempedido DROP CONSTRAINT fke813805872fee211;
ALTER TABLE ONLY public.plataforma DROP CONSTRAINT fke3cea86b1ac5b711;
ALTER TABLE ONLY public.pedido_itempedido DROP CONSTRAINT fk9b763172bf2c05ea;
ALTER TABLE ONLY public.pedido_itempedido DROP CONSTRAINT fk9b76317224befb51;
ALTER TABLE ONLY public.jogos DROP CONSTRAINT fk609c126fd08f77f;
ALTER TABLE ONLY public.jogos DROP CONSTRAINT fk609c12653493ed1;
ALTER TABLE ONLY public.jogos_plataforma DROP CONSTRAINT fk410f2924a62e4138;
ALTER TABLE ONLY public.jogos_plataforma DROP CONSTRAINT fk410f292442a90bb4;
ALTER TABLE ONLY public.jogos_imagem DROP CONSTRAINT fk204733cba62e4138;
ALTER TABLE ONLY public.jogos_imagem DROP CONSTRAINT fk204733cb8777d783;
ALTER TABLE ONLY public.plataforma DROP CONSTRAINT plataforma_pkey;
ALTER TABLE ONLY public.plataforma DROP CONSTRAINT plataforma_nome_key;
ALTER TABLE ONLY public.pedido DROP CONSTRAINT pedido_pkey;
ALTER TABLE ONLY public.pedido_itempedido DROP CONSTRAINT pedido_itempedido_itens_id_key;
ALTER TABLE ONLY public.jogos DROP CONSTRAINT jogos_pkey;
ALTER TABLE ONLY public.jogos DROP CONSTRAINT jogos_nome_key;
ALTER TABLE ONLY public.jogos_imagem DROP CONSTRAINT jogos_imagem_imagens_id_key;
ALTER TABLE ONLY public.itempedido DROP CONSTRAINT itempedido_pkey;
ALTER TABLE ONLY public.imagem DROP CONSTRAINT imagem_pkey;
ALTER TABLE ONLY public.fabricante DROP CONSTRAINT fabricante_pkey;
ALTER TABLE ONLY public.fabricante DROP CONSTRAINT fabricante_nome_key;
ALTER TABLE ONLY public.desenvolvedora DROP CONSTRAINT desenvolvedora_pkey;
ALTER TABLE ONLY public.desenvolvedora DROP CONSTRAINT desenvolvedora_nome_key;
DROP TABLE public.plataforma;
DROP TABLE public.pedido_itempedido;
DROP TABLE public.pedido;
DROP TABLE public.jogos_plataforma;
DROP TABLE public.jogos_imagem;
DROP TABLE public.jogos;
DROP TABLE public.itempedido;
DROP TABLE public.imagem;
DROP SEQUENCE public.hibernate_sequence;
DROP TABLE public.fabricante;
DROP TABLE public.desenvolvedora;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: desenvolvedora; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE desenvolvedora (
    id bigint NOT NULL,
    nome character varying(255)
);


ALTER TABLE public.desenvolvedora OWNER TO touch;

--
-- Name: fabricante; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE fabricante (
    id bigint NOT NULL,
    nome character varying(255)
);


ALTER TABLE public.fabricante OWNER TO touch;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: touch
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO touch;

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: touch
--

SELECT pg_catalog.setval('hibernate_sequence', 16, true);


--
-- Name: imagem; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE imagem (
    id bigint NOT NULL,
    bytes oid
);


ALTER TABLE public.imagem OWNER TO touch;

--
-- Name: itempedido; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE itempedido (
    id bigint NOT NULL,
    quantidade integer NOT NULL,
    jogo_id bigint,
    plataforma_id bigint
);


ALTER TABLE public.itempedido OWNER TO touch;

--
-- Name: jogos; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE jogos (
    id bigint NOT NULL,
    datalancamento timestamp without time zone,
    desconto integer NOT NULL,
    descricao character varying(255),
    genero integer,
    nome character varying(255),
    preco real,
    desenvolvedora_id bigint
);


ALTER TABLE public.jogos OWNER TO touch;

--
-- Name: jogos_imagem; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE jogos_imagem (
    jogos_id bigint NOT NULL,
    imagens_id bigint NOT NULL
);


ALTER TABLE public.jogos_imagem OWNER TO touch;

--
-- Name: jogos_plataforma; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE jogos_plataforma (
    jogos_id bigint NOT NULL,
    plataformas_id bigint NOT NULL
);


ALTER TABLE public.jogos_plataforma OWNER TO touch;

--
-- Name: pedido; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE pedido (
    id bigint NOT NULL,
    data timestamp without time zone
);


ALTER TABLE public.pedido OWNER TO touch;

--
-- Name: pedido_itempedido; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE pedido_itempedido (
    pedido_id bigint NOT NULL,
    itens_id bigint NOT NULL
);


ALTER TABLE public.pedido_itempedido OWNER TO touch;

--
-- Name: plataforma; Type: TABLE; Schema: public; Owner: touch; Tablespace: 
--

CREATE TABLE plataforma (
    id bigint NOT NULL,
    nome character varying(255),
    fabricante_id bigint
);


ALTER TABLE public.plataforma OWNER TO touch;

--
-- Data for Name: desenvolvedora; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY desenvolvedora (id, nome) FROM stdin;
\.
COPY desenvolvedora (id, nome) FROM '$$PATH$$/1845.dat';

--
-- Data for Name: fabricante; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY fabricante (id, nome) FROM stdin;
\.
COPY fabricante (id, nome) FROM '$$PATH$$/1846.dat';

--
-- Data for Name: imagem; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY imagem (id, bytes) FROM stdin;
\.
COPY imagem (id, bytes) FROM '$$PATH$$/1847.dat';

--
-- Data for Name: itempedido; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY itempedido (id, quantidade, jogo_id, plataforma_id) FROM stdin;
\.
COPY itempedido (id, quantidade, jogo_id, plataforma_id) FROM '$$PATH$$/1848.dat';

--
-- Data for Name: jogos; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY jogos (id, datalancamento, desconto, descricao, genero, nome, preco, desenvolvedora_id) FROM stdin;
\.
COPY jogos (id, datalancamento, desconto, descricao, genero, nome, preco, desenvolvedora_id) FROM '$$PATH$$/1852.dat';

--
-- Data for Name: jogos_imagem; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY jogos_imagem (jogos_id, imagens_id) FROM stdin;
\.
COPY jogos_imagem (jogos_id, imagens_id) FROM '$$PATH$$/1853.dat';

--
-- Data for Name: jogos_plataforma; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY jogos_plataforma (jogos_id, plataformas_id) FROM stdin;
\.
COPY jogos_plataforma (jogos_id, plataformas_id) FROM '$$PATH$$/1854.dat';

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY pedido (id, data) FROM stdin;
\.
COPY pedido (id, data) FROM '$$PATH$$/1849.dat';

--
-- Data for Name: pedido_itempedido; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY pedido_itempedido (pedido_id, itens_id) FROM stdin;
\.
COPY pedido_itempedido (pedido_id, itens_id) FROM '$$PATH$$/1850.dat';

--
-- Data for Name: plataforma; Type: TABLE DATA; Schema: public; Owner: touch
--

COPY plataforma (id, nome, fabricante_id) FROM stdin;
\.
COPY plataforma (id, nome, fabricante_id) FROM '$$PATH$$/1851.dat';

--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: 
--

SET search_path = pg_catalog;

\i $$PATH$$/1855.dat

--
-- Data for Name: BLOB COMMENTS; Type: BLOB COMMENTS; Schema: -; Owner: 
--

\i $$PATH$$/1856.dat

SET search_path = public, pg_catalog;

--
-- Name: desenvolvedora_nome_key; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY desenvolvedora
    ADD CONSTRAINT desenvolvedora_nome_key UNIQUE (nome);


--
-- Name: desenvolvedora_pkey; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY desenvolvedora
    ADD CONSTRAINT desenvolvedora_pkey PRIMARY KEY (id);


--
-- Name: fabricante_nome_key; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY fabricante
    ADD CONSTRAINT fabricante_nome_key UNIQUE (nome);


--
-- Name: fabricante_pkey; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY fabricante
    ADD CONSTRAINT fabricante_pkey PRIMARY KEY (id);


--
-- Name: imagem_pkey; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY imagem
    ADD CONSTRAINT imagem_pkey PRIMARY KEY (id);


--
-- Name: itempedido_pkey; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY itempedido
    ADD CONSTRAINT itempedido_pkey PRIMARY KEY (id);


--
-- Name: jogos_imagem_imagens_id_key; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY jogos_imagem
    ADD CONSTRAINT jogos_imagem_imagens_id_key UNIQUE (imagens_id);


--
-- Name: jogos_nome_key; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY jogos
    ADD CONSTRAINT jogos_nome_key UNIQUE (nome);


--
-- Name: jogos_pkey; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY jogos
    ADD CONSTRAINT jogos_pkey PRIMARY KEY (id);


--
-- Name: pedido_itempedido_itens_id_key; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY pedido_itempedido
    ADD CONSTRAINT pedido_itempedido_itens_id_key UNIQUE (itens_id);


--
-- Name: pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (id);


--
-- Name: plataforma_nome_key; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY plataforma
    ADD CONSTRAINT plataforma_nome_key UNIQUE (nome);


--
-- Name: plataforma_pkey; Type: CONSTRAINT; Schema: public; Owner: touch; Tablespace: 
--

ALTER TABLE ONLY plataforma
    ADD CONSTRAINT plataforma_pkey PRIMARY KEY (id);


--
-- Name: fk204733cb8777d783; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY jogos_imagem
    ADD CONSTRAINT fk204733cb8777d783 FOREIGN KEY (imagens_id) REFERENCES imagem(id);


--
-- Name: fk204733cba62e4138; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY jogos_imagem
    ADD CONSTRAINT fk204733cba62e4138 FOREIGN KEY (jogos_id) REFERENCES jogos(id);


--
-- Name: fk410f292442a90bb4; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY jogos_plataforma
    ADD CONSTRAINT fk410f292442a90bb4 FOREIGN KEY (plataformas_id) REFERENCES plataforma(id);


--
-- Name: fk410f2924a62e4138; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY jogos_plataforma
    ADD CONSTRAINT fk410f2924a62e4138 FOREIGN KEY (jogos_id) REFERENCES jogos(id);


--
-- Name: fk609c12653493ed1; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY jogos
    ADD CONSTRAINT fk609c12653493ed1 FOREIGN KEY (desenvolvedora_id) REFERENCES desenvolvedora(id);


--
-- Name: fk609c126fd08f77f; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY jogos
    ADD CONSTRAINT fk609c126fd08f77f FOREIGN KEY (id) REFERENCES jogos(id);


--
-- Name: fk9b76317224befb51; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY pedido_itempedido
    ADD CONSTRAINT fk9b76317224befb51 FOREIGN KEY (pedido_id) REFERENCES pedido(id);


--
-- Name: fk9b763172bf2c05ea; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY pedido_itempedido
    ADD CONSTRAINT fk9b763172bf2c05ea FOREIGN KEY (itens_id) REFERENCES itempedido(id);


--
-- Name: fke3cea86b1ac5b711; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY plataforma
    ADD CONSTRAINT fke3cea86b1ac5b711 FOREIGN KEY (fabricante_id) REFERENCES fabricante(id);


--
-- Name: fke813805872fee211; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY itempedido
    ADD CONSTRAINT fke813805872fee211 FOREIGN KEY (plataforma_id) REFERENCES plataforma(id);


--
-- Name: fke8138058a7a6bc11; Type: FK CONSTRAINT; Schema: public; Owner: touch
--

ALTER TABLE ONLY itempedido
    ADD CONSTRAINT fke8138058a7a6bc11 FOREIGN KEY (jogo_id) REFERENCES jogos(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

